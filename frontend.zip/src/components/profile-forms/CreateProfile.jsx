import React, { useState, useEffect, Fragment } from "react";
import { PropTypes } from "prop-types";
import { connect } from "react-redux";
import { Navigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Button, FormGroup, Input, Label } from "reactstrap";
import Select from "react-select";

const CreateProfile = ({ auth }) => {
  const { formData, setFormData } = useState({
    company: "",
    website: "",
    location: "",
    status: "",
    skills: [],
    githubusername: "",
    bio: "",
    twitter: "",
    facebook: "",
    linkedin: "",
    youtube: "",
    instagram: "",
  });

  if (!auth.isAuthenticated && !auth.loading) return <Navigate to="/login" />;

  //   const {
  //     company,
  //     website,
  //     location,
  //     status,
  //     skills,
  //     githubusername,
  //     bio,
  //     twitter,
  //     facebook,
  //     linkedin,
  //     youtube,
  //     instagram,
  //   } = formData;

  const professionalStatus = [
    { label: "Developer", value: "Developer" },
    { label: "Junior developer", value: "Junior developer" },
    { label: "Senior Developer", value: "Senior Developer" },
    { label: "Manager", value: "Manager" },
    { label: "Student or Learning", value: "Student or Learning" },
    { label: "Instructor or Teacher", value: "Instructor or Teacher" },
    { label: "Intern", value: "Intern" },
    { label: "Other", value: "Other" },
  ];

  return (
    <div className="container">
      <h2 className="large text-info">Create Your Profile</h2>
      <p className="lead">
        <FontAwesomeIcon icon={["fas", "user"]} />
        {"  "}
        <strong>
          Let's get some information to make your profile stand out
        </strong>
      </p>
      <small className="text-danger">Fields marked with * are required</small>
      <form className="form mt-3">
        <FormGroup>
          <Select options={professionalStatus} />

          <small className="form-text">
            Give us an idea of where you are at in your career
          </small>
        </FormGroup>
        <FormGroup>
          <Input type="text" name="company" placeholder="Company" />
          <small className="form-text">
            Could be your own company or one you work for
          </small>
        </FormGroup>
        <FormGroup>
          <Input type="text" name="website" placeholder="Website" />
          <small className="form-text">
            Could be your own or a company website
          </small>
        </FormGroup>
        <FormGroup>
          <Input type="text" name="location" placeholder="Location" />
          <small className="form-text">
            City & state suggested (eg. Boston, MA)
          </small>
        </FormGroup>
        <FormGroup>
          <Input type="text" name="skills" placeholder="Skills" />
          <small className="form-text">
            Please use comma separated values (eg. HTML,CSS,JavaScript,PHP)
          </small>
        </FormGroup>
        <FormGroup>
          <Input
            type="text"
            name="githubusername"
            placeholder="Github Username"
          />
          <small className="form-text">
            If you want your latest repos and a Github link, include your
            username
          </small>
        </FormGroup>
        <FormGroup>
          <Input type="textarea" name="bio" placeholder="Bio" />
          <small className="form-text">Tell us a little about yourself</small>
        </FormGroup>

        <div className="my-2">
          <button type="button" className="btn btn-light">
            Add Social Network Links
          </button>
          <span>Optional</span>
        </div>

        <div className="form-group social-input d-flex">
          <FontAwesomeIcon
            icon={["fab", "twitter"]}
            className="my-auto"
            size="lg"
          />

          <Input
            style={{ marginLeft: "1rem" }}
            type="text"
            name="twitter"
            placeholder="Twitter URL"
          />
        </div>

        <div className="form-group social-input d-flex">
          <FontAwesomeIcon
            icon={["fab", "facebook"]}
            className="my-auto"
            size="lg"
          />
          <Input
            style={{ marginLeft: "1rem" }}
            type="text"
            name="facebook"
            placeholder="Facebook URL"
          />
        </div>

        <div className="form-group social-input d-flex">
          <FontAwesomeIcon
            icon={["fab", "youtube"]}
            className="my-auto"
            size="lg"
          />
          <Input
            style={{ marginLeft: "0.8rem" }}
            type="text"
            name="youtube"
            placeholder="Youtube URL"
          />
        </div>

        <div className="form-group social-input d-flex">
          <FontAwesomeIcon
            icon={["fab", "linkedin"]}
            className="my-auto"
            size="lg"
          />
          <Input
            style={{ marginLeft: "1.1rem" }}
            type="text"
            name="linkedin"
            placeholder="Linkedin URL"
          />
        </div>

        <div className="form-group social-input d-flex">
          <FontAwesomeIcon
            icon={["fab", "instagram"]}
            className="my-auto"
            size="lg"
          />
          <Input
            style={{ marginLeft: "1.1rem" }}
            type="text"
            name="instagram"
            placeholder="Instagram URL"
          />
        </div>
        <div className="w-100">
          <Input type="submit" name="submit" className="btn-info w-auto" />
        </div>
        <Button className="btn-light my-2">Go back</Button>
      </form>
    </div>
  );
};

CreateProfile.propTypes = {
  auth: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
});

export default connect(mapStateToProps, {})(CreateProfile);
