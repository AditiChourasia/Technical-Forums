import axios from "axios";
import { setAlert } from "./alert";
import { GET_PROFILE, PROFILE_ERROR } from "./types";
import { BASE_URL } from "./../config/default";

//Get current user profile
export const getCurrentProfile = () => async (dispatch) => {
  console.log("Profile Requested");
  try {
    const res = await axios.get(BASE_URL + "/api/profile/me");
    console.log("Profile data", res);

    dispatch({
      type: GET_PROFILE,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
    dispatch({
      type: PROFILE_ERROR,
      payload: {
        msg: err.response.data.msg,
        status: err.response.status,
      },
    });
  }
};
